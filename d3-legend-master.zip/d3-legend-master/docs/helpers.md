d3.**legendHelpers()**

Convenience functions for using this module

legendHelpers.**thresholdLabels**

Changes the labels so the first one label says "Less than _first-threshold_" and the last one says "More than _last-threshold_".
Example: [Color - Threshold Scale, Custom Labels](#color-threshold)
